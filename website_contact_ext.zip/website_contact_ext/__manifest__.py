
{
    'name': 'Website Contact Extended',
    'summary': 'Checks condition before creating contacts',
    'version': '13.0.1.0.0',
    'category': 'Website',
    'author': 'Kamlesh',
    'license': 'LGPL-3',
    'application': True,
    'installable': True,
    'depends': [
        'website_form',
    ],
    'data': [
    ],
}
